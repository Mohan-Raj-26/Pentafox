diameter=7
round1=int(input())
r=7/2
cir=2*3.14*r
distance=cir*round1
print(str(distance)+" kms travelled")